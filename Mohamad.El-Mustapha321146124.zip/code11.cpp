#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>

// Logging messages into a file

    void logMessage(const std::string& message) {
    std::fstream File("saved_communications.txt", std::ios_base::out);

    if (File.is_open()) {
        File << message << '\n' ;
        File.close();

    } else {
        std::cerr << "File Not Opening."<< std::endl ;
    }
    }

    int main() {
    // Open the serial port
    HANDLE serialHandle = CreateFile(TEXT("COM3"), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (serialHandle == INVALID_HANDLE_VALUE) {
        std::cerr << "Error, Serial Port not Opening." << std::endl;
        return 1;
    }

    // Setting serial port parameters
    DCB serialParams = {0};
    serialParams.DCBlength = sizeof(serialParams);
    if (!GetCommState(serialHandle, &serialParams)) {
        std::cerr << "Error: Could not get serial port state." << std::endl;
        CloseHandle(serialHandle);
        return 1;
    }
    serialParams.BaudRate = CBR_19200;    // moderate speed
    serialParams.ByteSize = 8;           // standard byte size
    serialParams.StopBits = ONESTOPBIT; // 1 stop bits 
    serialParams.Parity = NOPARITY;     // simple error checking

    if (!SetCommState(serialHandle, &serialParams)) {
        std::cerr << "Serial Port Not Opening." << std::endl;
        CloseHandle(serialHandle);
        return 1;
    }

    double first_number, second_number; // gives good precision 
    char operation;
    std::cout << "Enter the first_number: ";
    std::cin >> first_number;

    //Ask for the operation from the user
    std::cout << "Enter the operation (+, -, *, /): ";
    std::cin >> operation;
    if (operation != '+' && operation != '-' && operation != '*' && operation != '/') {
        std::cerr << "Invalid operation." << std::endl;
        CloseHandle(serialHandle);
        return 1;
    }
    std::cout << "Enter the second_number: ";
    std::cin >> second_number;

    //Sending the strings
    std::string dataToSend = std::to_string(first_number) + "," + operation + "," + std::to_string(second_number) + "\n";
    std::cout << "Sending Values: " << dataToSend << '\n' ;

    //Logging the sent data
    logMessage("Sent: " + dataToSend);

    //Writing data to the serial port
    DWORD bytesWritten;
    if (!WriteFile(serialHandle, dataToSend.c_str(), dataToSend.length(), &bytesWritten, NULL)) {
        std::cerr << "Error Not written to serial port." << std::endl;
        CloseHandle(serialHandle);
        return 1;
    }

    //Reading the result from the serial port
    char buffer[512];
    DWORD bytesRead;
    if (!ReadFile(serialHandle, buffer, sizeof(buffer), &bytesRead, NULL)) {
        std::cerr << "Could not read from serial port." << std::endl;
        CloseHandle(serialHandle);
        return 1;
    }
     // Ensure to be treated as C style String
    buffer[bytesRead] = '\0';

    std::cout << "The Result is: " << buffer << '\n';
    logMessage("Received: " + std::string(buffer));

    // Closing the serial port
    CloseHandle(serialHandle);
    return 0;
}
